const int S0 = 26;
const int S1 = 27;
const int in = 25;

void Traffic_lights() {


  // Serial.println(time);
  // Serial.println(current_time);
  // Serial.println(time_circle);

  /* if (yellow_flashing_state == "on" && os_state == "off" && manual_mode_state == "off") {
    //  if (yellow_flashing_state == "on") {
    if (time_circle == 0) {
      digitalWrite(S1, LOW);
      digitalWrite(S0, LOW);
    }
    if (time_circle == 1) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
    }
    if (time_circle == 84) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
    }
    if (time_circle == 87) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
    }
    if (time_circle == 88) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
    }
    if (time_circle == 89) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
    }
   
  }*/
  if (yellow_flashing_state == "on" && os_state == "off" && manual_mode_state == "off") {
    //  if (yellow_flashing_state == "on") {
    digitalWrite(S1, LOW);
    digitalWrite(S0, LOW);
    vTaskDelay(10);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(830);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, HIGH);
    vTaskDelay(30);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(10);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, HIGH);
    vTaskDelay(10);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(110);
  }
  if (os_state == "on" && yellow_flashing_state == "off" && manual_mode_state == "off") {
    digitalWrite(S1, LOW);
    digitalWrite(S0, LOW);
    vTaskDelay(10);

    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);

    vTaskDelay(830);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, HIGH);
    vTaskDelay(40);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(120);
  }
  //Serial.println(faza);
  if (manual_mode_state == "on" && faza > 0) {

    digitalWrite(S1, LOW);
    digitalWrite(S0, LOW);
    vTaskDelay(10);

    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(790);

    if (faza == 1) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(70);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    
    if (faza == 2) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(60);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    if (faza == 3) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(60);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(120);
    }
    if (faza == 4) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(50);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    if (faza == 5) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(50);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(120);
    }
    if (faza == 6) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(50);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(130);
    }
    if (faza == 7) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(50);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    if (faza == 8) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(30);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    if (faza == 8) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(120);
    }
    if (faza == 10) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(130);
    }
    if (faza == 11) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(10);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(30);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(110);
    }
    if (faza == 12) {
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(40);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, HIGH);
      vTaskDelay(20);
      digitalWrite(S1, HIGH);
      digitalWrite(S0, LOW);
      vTaskDelay(140);
    }
  }
  /*if (yellow_flashing_state == "on" && os_state == "off" && all_red_state == "off") {
    //  if (yellow_flashing_state == "on") {
 
    digitalWrite(S1, LOW);
    digitalWrite(S0, LOW);
    vTaskDelay(10);
 
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
 
    vTaskDelay(830);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, HIGH);
    vTaskDelay(30);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(10);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, HIGH);
    vTaskDelay(10);
    digitalWrite(S1, HIGH);
    digitalWrite(S0, LOW);
    vTaskDelay(110);
  }*/
  //  ++time_circle;
  //   if (time_circle == 100)
  //     time_circle = 0;
}