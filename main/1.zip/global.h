//const String default_ssid = "YOTA-1077";
//const String default_wifipassword = "1qaz2WSX";
// const String default_ssid = "Keenetic-8413";
// const String default_wifipassword = "Zavulon56";
// const int default_webserverporthttp = 80;
//bool there_config = false;

StaticJsonDocument<10240> doc;
//String (F(f_n));
//unsigned char faza = 0;
int faza = 0;
String main_mode_state = "on";
String yellow_flashing_state = "off";
String os_state = "off";
String manual_mode_state = "off";
bool there_config = false;            //   файл конфигурации
unsigned char time_circle = 0;
unsigned long last_time = 0;
unsigned long current_time = 0;
File fsUploadFile;


String findJson();
void jsonread();
void configureWebServer();
//void handleUpload(AsyncWebServerRequest *, String, size_t, uint8_t *, size_t, bool);
